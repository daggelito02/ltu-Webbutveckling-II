<footer>
    <p>
        Luleå tekniska universitet | Webbutveckling II - Skriptspråk och databaser
        | dagfre-3 | 2024
    </p>
</footer>
