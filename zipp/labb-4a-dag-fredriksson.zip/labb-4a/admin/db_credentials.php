<?php
    define("DB_SERVER", "localhost");
    define("DB_USER", "root");
    define("DB_PASS", "");
    define("DB_NAME", "CMS");

    // define("DB_SERVER", "utbweb.its.ltu.se:3308");
    // define("DB_USER", "dagfre3");
    // define("DB_PASS", "jcmc8ncJ");
    // define("DB_NAME", "D0019E_V24_dagfre3");
?>