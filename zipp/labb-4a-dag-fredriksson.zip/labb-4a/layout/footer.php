<p>
    Luleå tekniska universitet | Webbutveckling II - Skriptspråk och databaser
    | dagfre-3 | 2024
</p>
<div id="cookie-consent-terms" class="cookie-container">
    <p>Eftersom vi spar lite användardata behöver du godkänna vår policy!. 
        <a class="accept-cookie-link" target="_blank" href="https://en.wikipedia.org/wiki/Acceptable_use_policy">Läs mer om policy</a>.
    </p>
    <button id="accept-cookie" class="button-accept">Acceptera</button>
</div>
<script src="javascript/cookie_consent.js"></script>
